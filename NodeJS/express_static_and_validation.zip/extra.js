var my = require('./myfile.json');
console.log(my);
console.log(my[0].name);














/*var path = require('path');
var filePath = "C:\\Node\\MyApp//Views\\Index.html";
console.log(path);
console.log("PATH: " + filePath);

filePath = path.normalize(filePath);

console.log("NORMALIZE: " + filePath);
console.log("DIRNAME: " + path.dirname(filePath));
console.log("BASENAMAE: " + path.basename(filePath));
console.log("EXTNAME: " + path.extname(filePath));
console.log("NEWPATH: " + path.join(path.dirname(filePath), path.basename(filePath)));*/
