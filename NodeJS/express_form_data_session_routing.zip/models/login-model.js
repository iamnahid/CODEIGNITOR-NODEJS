module.exports = {
	verifyUser: function(user, callback){
		if(user.username == user.password)
		{
			callback(true);
		}
		else
		{
			callback(false);
		}
	}
};