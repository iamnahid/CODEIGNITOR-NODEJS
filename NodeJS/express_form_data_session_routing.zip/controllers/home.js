var express = require('express');
var router = express.Router();

router.get('/home', function(req, res){
	if(req.session.loggedUser)
	{
		res.render('home/index', {user: req.session.loggedUser});
	}
	else
	{
		res.redirect('/login');
	}
});

module.exports = router;