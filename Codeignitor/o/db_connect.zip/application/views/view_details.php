<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h2>Account Details</h2>

	<table border="1">
		<tr>
			<td><b>ID</b></td>
			<td><?php echo $id; ?></td>
		</tr>
		<tr>
			<td><b>ACC NO</b></td>
			<td><?php echo $acc_no; ?></td>
		</tr>
		<tr>
			<td><b>ACC NAME</b></td>
			<td><?php echo $acc_name; ?></td>
		</tr>
		<tr>
			<td><b>BALANCE</b></td>
			<td><?php echo $balance; ?></td>
		</tr>
	</table>
	<br/>
	<a href="http://localhost/ci226/account">Go Back</a>
</body>
</html>

