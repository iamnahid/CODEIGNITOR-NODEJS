<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h2>Add New Account</h2>
	<form method="post">
		<table>
			<tr>
				<td>ACC NO</td>
				<td><input type="text" name="accno"></td>
			</tr>
			<tr>
				<td>ACC NAME</td>
				<td><input type="text" name="accname"></td>
			</tr>
			<tr>
				<td>INIT BALANCE</td>
				<td><input type="text" name="balance"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="buttonSave" value="Save"></td>
			</tr>
		</table>
	</form>
</body>
</html>